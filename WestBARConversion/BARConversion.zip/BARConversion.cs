﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MeditechLibrary.BAR._61X_V2;
using WestBARConversion.CernerCore;
using WestBARConversion.CernerModel;

namespace WestBARConversion
{
    public class BARConversion
    {
        private static BARForm frm;
        private string _hcis = string.Empty;
        private string _hospFac = string.Empty;
        private string _barStatus = string.Empty;
        private string _grouperVersion = string.Empty;
        private decimal? _globalFBBalance = 0;
        private decimal? _globalBDBalance = 0;
        private BAR mtBAR = null;
        private Hashtable _globalInsHash;
        public void Convert(BARForm f,string barStatus, string hospName, string outputPath, string hcis)
        {
            string timein = "";
            string timeout = "";
            int acctCnt = 0;
            int encntrCnt = 0;
            int notFound = 0;

            frm = f;
            _hcis = hcis;
            _barStatus = barStatus;
            //_hospFac = hospFac;
            timein = DateTime.Now.ToString();

            //List<string> invalidPersons = MPIExclusionDAL.GetInactivePersonIds();
            //List<string> organizations = GetOrganizations(_hcis, "'MVHX'");
            //List<string> organizations = GetOrganizations(_hcis, "'SLHX','TSHX'");
            //List<string> organizations = GetOrganizations(_hcis,"'SBHX'");// "MVHX");
            //List<string> organizations = GetOrganizations(_hcis,"'DHHX'");
            //List<string> organizations = GetOrganizations(_hcis, "'LAHX'");
            List<string> organizations = GetOrganizations(_hcis,hospName);

            mtBAR = new BAR(hospName, outputPath, _hcis, _barStatus);
            List<string> encounterIds = EncounterDAL.GetDistinctEncounterIds(organizations);
            //encounterIds.Insert(0, "126182873.0000");
            
            foreach (string encounterId in encounterIds)
            {
                List<PFT_Encntr> pft_encntrs = PftEncntrDAL.GetPFT_Encntrs(CernerCommon.StripDecimalsForMap(encounterId));
                if (pft_encntrs.Count > 0)
                {
                    Encounter encounter = EncounterDAL.GetEncounter(encounterId);
                    Person person = PersonDAL.GetPerson(encounter.Person_Id);

                    MPIOrganization org = MPIOrganizationDAL.GetOrganization(CernerCommon.StripDecimalsForMap(encounter.Organization_Id));
                    
                    string mrn = org.MRNPrefix + CernerCommon.StripDecimalsForMap(encounter.Person_Id).PadLeft(8, char.Parse("0"));
                    string facility = org.Facility;

                    foreach (PFT_Encntr pft_Encntr in pft_encntrs)
                    {
                        if (pft_Encntr.Recur_Seq == "0")//Remove
                        {
                            if(barStatus == "BD")
                            {
                                if (pft_Encntr.Bad_Debt_Dt_Tm != null)
                                {
                                    if (pft_Encntr.Bad_Debt_Balance != 0)
                                    {
                                        ProcessAccount(pft_Encntr, encounter, person, org, mrn, facility);
                                        acctCnt++;
                                    }
                                }
                            }
                            else if (barStatus == "FB")
                            {
                                if (pft_Encntr.Bad_Debt_Dt_Tm == null)
                                {
                                    if (pft_Encntr.Balance != 0)
                                    {
                                        ProcessAccount(pft_Encntr, encounter, person, org, mrn, facility);
                                        acctCnt++;
                                    }
                                }
                            }
                            else if (barStatus == "ZERO")
                            {
                                if (pft_Encntr.Bad_Debt_Dt_Tm != null)
                                {
                                    if (pft_Encntr.Balance == 0)
                                    {
                                        ProcessAccount(pft_Encntr, encounter, person, org, mrn, facility);
                                        acctCnt++;
                                    }
                                }
                            }
                        }
                    }
                }
                encntrCnt++;
                if (encntrCnt % 10 == 0)
                    frm.DisplayResults(hcis + " - " + acctCnt.ToString() + " / " + encntrCnt.ToString() + "  Start Time: " + timein);
                if (acctCnt > 7500)
                    break;
            }
            if(_barStatus == "FB")
                mtBAR.SetEndingBalance(_globalFBBalance,_barStatus);
            else if (_barStatus == "BD")
                mtBAR.SetEndingBalance(_globalBDBalance, _barStatus);
            mtBAR.UnInit();
            timeout = DateTime.Now.ToString();
            frm.DisplayResults(hcis + " - " + acctCnt.ToString() + " / " + encntrCnt.ToString() + "  Start Time: " + timein + "  End Time: " + timeout);
        }

        private void ProcessAccount(PFT_Encntr pft_Encnter, Encounter encounter, Person person, MPIOrganization org, string mrn, string facility)
        {
            string acctNbr = "";
            string gtrPersonId = "";
            string gtrRel = "";
            List<Encntr_Person_Reltn> eprs = EncntrPersonReltDAL.GetGuarantor(encounter.Original_Encounter_Id);
            foreach (Encntr_Person_Reltn epr in eprs)
            {
                gtrPersonId = epr.guarPersonID;
                gtrRel = epr.relationship;
            }
            if (gtrPersonId == "")
                gtrPersonId = person.PersonId;
            Person guarantor = PersonDAL.GetPerson(gtrPersonId);
            Employer patientEmp = PersonOrgReltDAL.GetEmployer(person.PersonId.Replace(".0000",""));
            Employer guarEmp = PersonOrgReltDAL.GetEmployer(gtrPersonId.Replace(".0000", ""));
            List<Diagnosis> admitDxs = DiagnosisDAL.GetEncounterAdmitDxs(encounter.Original_Encounter_Id.Replace(".0000",string.Empty)); //remember - encounterdal strips this value - use the orig encoutner id property if you need that
            List<Drg> drgs = DRGDAL.GetEncounterDRG(encounter.Original_Encounter_Id.Replace(".0000", string.Empty));
            List<Diagnosis> finalDxs = DiagnosisDAL.GetEncounterFinalDxs(encounter.Original_Encounter_Id.Replace(".0000", string.Empty));
            List<Procedure_Obj> procedures = ProcedureDAL.GetEncounterProcedures(encounter.Original_Encounter_Id.Replace(".0000", string.Empty));
            List<Provider> providers = EncntrPrsnlReltnDAL.GetEncounterPhysicians(encounter.Original_Encounter_Id, facility);
            List<string> conditionCodes = Encntr_Condition_CodeDAL.GetConditionCodes(encounter.Original_Encounter_Id);
            List<Occurrence_Code> occurrenceCodes = Encntr_Occurrence_CodeDAL.GetOccurrence_Codes(encounter.Original_Encounter_Id);
            List<Value_Code> valueCodes = Encntr_Value_CodeDAL.GetEncounterValueCodes(encounter.Original_Encounter_Id);
            List<Encntr_Plan_Reltn> encPlans = Encntr_Plan_ReltnDAL.GetEncounterPlans(encounter.Original_Encounter_Id);
            List<PftProration> pftProrate = Pft_Proration_DAL.GetPFTProration(pft_Encnter.Pft_Encntr_Id);
            

            mtBAR.InitPatient();
            acctNbr = encounter.Encounter_Id.Trim();
            if (acctNbr.Length > 2)
                acctNbr = acctNbr.Substring(2);

            mtBAR.CurrentAccountNumber = org.AcctPrefix + acctNbr.Trim().PadLeft(10,'0');
            mtBAR.CurrentMRN = mrn;

            PatientDemogrpahics(person, encounter, facility);
            PatientEmployer(patientEmp);
            AccountInfo(pft_Encnter, encounter, org.AcctPrefix);
            Providers(providers);
            PatientDiagnosis(admitDxs, finalDxs);
            PatientConditionCodes(conditionCodes);
            PatientOccurenceAndSpanCodes(occurrenceCodes);
            PatientValueCodes(valueCodes);
            InpatientCodes(drgs);
            PatientProcedures(procedures);
            OutpatientAPCHCPCSCodes(procedures);
            OutpatientCPTCodes(procedures);
            PatientGuarantor(guarantor, gtrRel);
            PatientGuarantorEmployer(guarEmp);
            _globalInsHash = new Hashtable();
            PatientInsurances(encPlans);
            //PatientQueries();
            CurrentBalance(pft_Encnter, pftProrate);
            ProcessChargesTransactions(pft_Encnter, facility);
            //ProcessComments

            mtBAR.Print();
        }

        private void PatientDemogrpahics(Person person, Encounter encounter, string facility)
        {
            mtBAR.PatientDemo.AccountNumber = mtBAR.CurrentAccountNumber;
            mtBAR.PatientDemo.Name = person.FullName();
            mtBAR.PatientDemo.MedicalRecordNumber = mtBAR.CurrentMRN;
            mtBAR.PatientDemo.SocialSecurityNumber = CernerCommon.GetSSN(person.SocialSecurityNumber);
            if (person.HomeAddress != null)
            {
                mtBAR.PatientDemo.AddressLine1 = person.HomeAddress.Street_Addr;
                mtBAR.PatientDemo.AddressLine2 = person.HomeAddress.Street_Addr2;
                mtBAR.PatientDemo.City = person.HomeAddress.City;
                mtBAR.PatientDemo.State = person.HomeAddress.State_Cd;
                mtBAR.PatientDemo.ZipCode = person.HomeAddress.ZipCode;
            }
            else
            {
                mtBAR.PatientDemo.AddressLine1 = string.Empty; 
                mtBAR.PatientDemo.AddressLine2 = string.Empty;
                mtBAR.PatientDemo.City = string.Empty;
                mtBAR.PatientDemo.State = string.Empty;
                mtBAR.PatientDemo.ZipCode = string.Empty;
            }
            if (person.HomePhone != null)
                mtBAR.PatientDemo.HomePhone = person.HomePhone.Phone_Num;
            else
                mtBAR.PatientDemo.HomePhone = string.Empty;
            mtBAR.PatientDemo.Race = person.Race_Cd;
            mtBAR.PatientDemo.Sex = person.Sex_Cd;
            mtBAR.PatientDemo.BirthDate = CernerCommon.GetCernerDate(person.Birth_Dt_Tm);
            mtBAR.PatientDemo.MaritalStatus = person.Marital_Type_Cd;
            mtBAR.PatientDemo.Facility = facility;
            mtBAR.PatientDemo.AlternateAddress = string.Empty;
            if (encounter.ConfidentialVisit == ".0000" || encounter.ConfidentialVisit == "null" || encounter.ConfidentialVisit == "")
                mtBAR.PatientDemo.Confidential = "";
            else
                mtBAR.PatientDemo.Confidential = "Y";
            if (encounter.VIP_Cd == ".0000" || encounter.VIP_Cd == "null" || encounter.VIP_Cd == "")
                mtBAR.PatientDemo.VIP = "";
            else
                mtBAR.PatientDemo.VIP = "Y";
        }
        
        private void PatientEmployer(Employer patientEmp)
        {
            string addr1 = "";
            string addr2 = "";
            string city = "";
            string state = "";
            string zip = "";
            string phone = "";
            if(patientEmp.WorkAddress != null)
            {
                addr1 = patientEmp.WorkAddress.Street_Addr;
                addr2 = patientEmp.WorkAddress.Street_Addr2;
                city = patientEmp.WorkAddress.City;
                state = patientEmp.WorkAddress.State_Cd;
                zip = patientEmp.WorkAddress.ZipCode;
            }
            if (patientEmp.WorkPhone != null)
            { 
                phone = patientEmp.WorkPhone.Phone_Num;
            }
            if(patientEmp.EmployerName != null)
                mtBAR.UpdatePatientEmployer(patientEmp.EmployerName, addr1, addr2, city, state, zip, phone,  "",patientEmp.Occupation, patientEmp.EmploymentStatus, "");
        }
        private void AccountInfo(PFT_Encntr pft_Encnter, Encounter encounter, string orgPrefix)
        {
            mtBAR.AccountInfo.AccountNumber = mtBAR.PatientDemo.AccountNumber;
            mtBAR.AccountInfo.ARStatus = _barStatus;
            mtBAR.AccountInfo.PatientStatus = encounter.BAR_Encounter_Type_Cd; //using bar encounter type
            mtBAR.AccountInfo.PatientService = encounter.Med_Serv_Cd; //using mpi map
            mtBAR.AccountInfo.PatientLocation = encounter.Loc_Nurse_Unit_Cd; //using mpi map
            mtBAR.AccountInfo.AdmitDate = CernerCommon.GetCernerDate(encounter.Reg_Dt_Tm, _hcis); //have to convert string date and time zone to get datetype
            mtBAR.AccountInfo.AdmitTime = FormatDT(mtBAR.AccountInfo.AdmitDate.ToString(), "time");
            mtBAR.AccountInfo.AdmitPriority = encounter.Admit_Type_Cd;  //need to get map
            mtBAR.AccountInfo.AdmitSource = encounter.Admit_Src_Cd; //need to get map
            mtBAR.AccountInfo.DischargeDate = CernerCommon.GetCernerDate(encounter.Disch_Dt_Tm, _hcis); //have to convert string date and time zone to get datetype
            mtBAR.AccountInfo.AdmitTime = FormatDT(mtBAR.AccountInfo.DischargeDate.ToString(), "time");
            mtBAR.AccountInfo.DischargeDisposition = encounter.Disch_Disposition_Cd; //mapped in encounterDAL object

            if (pft_Encnter.Zero_Balance_Dt_Tm.HasValue)
                mtBAR.AccountInfo.ZeroDate = pft_Encnter.Zero_Balance_Dt_Tm;
            mtBAR.AccountInfo.TotalCharges = pft_Encnter.Charge_Balance;

            if (encounter.Admit_Type_Cd == "670841")
            {
                mtBAR.AccountInfo.MotherAccountNumber = EncntrMotherChildDAL.GetMotherAcctNumber(encounter.Encounter_Id, orgPrefix);
                mtBAR.AccountInfo.NewbornAdmitSource = encounter.Admit_Src_Cd;
            }
            mtBAR.AccountInfo.AbstractStatus = string.Empty;
            SetGrouperVersion(CernerCommon.GetCernerDate(encounter.Disch_Dt_Tm, _hcis));
        }
        private void Providers(List<Provider> providers)
        {
            foreach(Provider provider in providers)
            {
                string physMnemonic = provider.Mnemonic;
                string name = provider.FullName();
                string addr1 = string.Empty;
                string addr2 = string.Empty;
                string city = string.Empty;
                string state = string.Empty;
                string zipCode = string.Empty;
                string homePhone = string.Empty;
                string npi = provider.NPI;
                string licenseNbr = provider.License;
                string physType = provider.PhysicianType;

                if (provider.HomeAddress != null)
                {
                    addr1 = provider.HomeAddress.Street_Addr;
                    addr2 = provider.HomeAddress.Street_Addr2;
                    city = provider.HomeAddress.Street_Addr;
                    state = provider.HomeAddress.Street_Addr;
                    zipCode = provider.HomeAddress.Street_Addr;
                }
                if (provider.HomePhone != null)
                {
                    homePhone = provider.HomePhone.Phone_Num;
                }
                mtBAR.AddProvider(physMnemonic, name, addr1, addr2, city, state, zipCode, homePhone, npi, licenseNbr, physType);
            }
        }

        private void PatientDiagnosis(List<Diagnosis> admitDxs, List<Diagnosis> finalDxs)
        {
            string admitType = "A"; //defualt to Admit - set in finalDx where cnt = 1,P else 'S'
            if (admitDxs.Count > 0)
            {
                Diagnosis admitDx = admitDxs[0];
                mtBAR.AddDiagnosis(admitDx.DxCode, _grouperVersion, admitDx.POA, admitType);
            }
            
            int cnt = 0;
            foreach(Diagnosis finalDx in finalDxs)
            {
                cnt++;
                if (cnt == 1)
                    admitType = "P";
                else
                    admitType = "S";

                mtBAR.AddDiagnosis(finalDx.DxCode, _grouperVersion, finalDx.POA, admitType);
            }

            
        }
        private void PatientConditionCodes(List<string> condCodes)
        {
            foreach(string code in condCodes)
            {
                mtBAR.AddConditionCode(code);
            }
        }

        private void PatientOccurenceAndSpanCodes(List<Occurrence_Code> occurCodes)
        {
            foreach(Occurrence_Code code in occurCodes)
            {
                mtBAR.AddOccurenceCode(code.OccurrenceCode, code.OccurrenceDate);
            }
        }

        private void PatientValueCodes(List<Value_Code> valueCodes)
        {
            foreach(Value_Code code in valueCodes)
            {
                mtBAR.AddValue(code.ValueCode, code.ValueAmount);
            }
            
        }
        private void InpatientCodes(List<Drg> drgs)
        {
            int cnt = 0;
            foreach (Drg drg in drgs)
            {
                cnt++;
                
                mtBAR.UpdateImpatientCodes(drg.DrgCode,"F","","","","",null,null);
            }
        }
        private void PatientProcedures(List<Procedure_Obj> procedures)
        {
            
            foreach(Procedure_Obj proc in procedures)
            {
                if (proc.SourceVocabCd.Trim() == "19350130")
                {
                    DateTime? procDate = CernerCommon.ConvertDateString(proc.ProcedureDateTime);
                    mtBAR.AddInpatientProcedure(proc.ProcCode, _grouperVersion, procDate, proc.ProcedurePhy);
                }
            }
        }
        private void OutpatientAPCHCPCSCodes(List<Procedure_Obj> procedures)
        {
            string hcpcs = "";
            foreach (Procedure_Obj proc in procedures)
            {
                if (proc.SourceVocabCd.Trim() == "1222")
                {
                    hcpcs = hcpcs + "|" + proc.ProcCode;
                }
            }
            if (hcpcs.Length > 0)
                hcpcs = hcpcs.Substring(1);
            mtBAR.AddOutPatientHCPCS(hcpcs);
        }
        private void OutpatientCPTCodes(List<Procedure_Obj> procedures)
        {
            foreach (Procedure_Obj proc in procedures)
            {
                if (proc.SourceVocabCd.Trim() == "1217")
                {
                    DateTime? procDate = CernerCommon.ConvertDateString(proc.ProcedureDateTime);
                    mtBAR.AddOutPatientCPT(proc.ProcCode, procDate, "", proc.ProcedurePhy, proc.ProcedurePhyAsst);
                }
            }
        }
        private void PatientGuarantor(Person guarantor, string guarRel)
        {
            
            string name = guarantor.FullName();
            string addr1 = string.Empty;
            string addr2 = string.Empty;
            string city = string.Empty;
            string state = string.Empty;
            string zipCode = string.Empty;
            string homePhone = string.Empty;
            string workPhone = string.Empty;

            if (guarantor.HomeAddress != null)
            {
                addr1 = guarantor.HomeAddress.Street_Addr;
                addr2 = guarantor.HomeAddress.Street_Addr2;
                city = guarantor.HomeAddress.City;
                state = guarantor.HomeAddress.State_Cd;
                zipCode = guarantor.HomeAddress.ZipCode;
            }
            if (guarantor.HomePhone != null)
                homePhone = guarantor.HomePhone.Phone_Num;
            if (guarantor.WorkPhone != null)
                workPhone = guarantor.WorkPhone.Phone_Num;

            string ssn = CernerCommon.GetSSN(guarantor.SocialSecurityNumber);
            string gtrNbr = ssn.Replace("-","");
            string relToPatient = guarRel;
            string mostRecentVisit = string.Empty;
            string institutionGuarantor = string.Empty;

            mtBAR.UpdateGuarantor(gtrNbr, name, addr1, addr2, city, state, zipCode, homePhone, workPhone, ssn, relToPatient, mostRecentVisit, institutionGuarantor);
        }
        private void PatientGuarantorEmployer(Employer guarEmp)
        {
            string addr1 = "";
            string addr2 = "";
            string city = "";
            string state = "";
            string zip = "";
            string phone = "";
            if (guarEmp.WorkAddress != null)
            {
                addr1 = guarEmp.WorkAddress.Street_Addr;
                addr2 = guarEmp.WorkAddress.Street_Addr2;
                city = guarEmp.WorkAddress.City;
                state = guarEmp.WorkAddress.State_Cd;
                zip = guarEmp.WorkAddress.ZipCode;
            }
            if (guarEmp.WorkPhone != null)
            {
                phone = guarEmp.WorkPhone.Phone_Num;
            }
            if (guarEmp.EmployerName != null)
                mtBAR.UpdateGuarantorEmployer(guarEmp.EmployerName, addr1, addr2, city, state, zip, phone, "", guarEmp.Occupation, guarEmp.EmploymentStatus, "");
        }
        
        private void PatientInsurances(List<Encntr_Plan_Reltn> encPlans)
        {
            int cnt = 0;
            string addr1 = string.Empty;
            string addr2 = string.Empty;
            string city = string.Empty;
            string state = string.Empty;
            string zipCode = string.Empty;
            string businessPhone = string.Empty;
            string workPhone = string.Empty;
            string country = string.Empty;
            string emailAddr = string.Empty;

            foreach (Encntr_Plan_Reltn encPlan in encPlans)
            {
                cnt = cnt + 1;

                if (_globalInsHash.Contains(cnt) == false)
                    _globalInsHash.Add(cnt, encPlan.InsuranceCode);

                if (encPlan.Address != null)
                {
                    addr1 = encPlan.Address.Street_Addr;
                    addr2 = encPlan.Address.Street_Addr2;
                    city = encPlan.Address.City;
                    state = encPlan.Address.State_Cd;
                    zipCode = encPlan.Address.ZipCode;
                }
                else
                {
                    addr1 = string.Empty;
                    addr2 = string.Empty;
                    city = string.Empty;
                    state = string.Empty;
                    zipCode = string.Empty;
                }
                if (encPlan.InsurancePhone != null)
                    businessPhone = encPlan.InsurancePhone.Phone_Num;
                else
                    businessPhone = string.Empty;
                string polNbr = encPlan.PolicyNbr;
                if (polNbr.Trim() == "null")
                    polNbr = "";
                mtBAR.AddInsurance(cnt, encPlan.InsuranceCode, encPlan.InsuranceName, addr1, addr2, city, state, zipCode, businessPhone,
                                   ConvertDate(encPlan.EffectiveDate), 0, 0, 0, encPlan.InsEligibilitySts, ConvertDate(encPlan.StatusDate), ConvertDate(encPlan.InsuranceExpdate), polNbr, encPlan.GroupNbr, encPlan.GroupName, encPlan.CoverageNbr);

                if (encPlan.SubscriberPerson != null)
                {
                    if (encPlan.SubscriberAddress != null)
                    {
                        addr1 = encPlan.SubscriberAddress.Street_Addr;
                        addr2 = encPlan.SubscriberAddress.Street_Addr2;
                        city = encPlan.SubscriberAddress.City;
                        state = encPlan.SubscriberAddress.State_Cd;
                        zipCode = encPlan.SubscriberAddress.ZipCode;
                        country = encPlan.SubscriberAddress.Country;
                    }
                    else
                    {
                        addr1 = string.Empty;
                        addr2 = string.Empty;
                        city = string.Empty;
                        state = string.Empty;
                        zipCode = string.Empty;
                        country = string.Empty;
                    }
                    if (encPlan.SubscriberPhone != null)
                        businessPhone = encPlan.SubscriberPhone.Phone_Num;
                    else
                        businessPhone = string.Empty;
                    if (encPlan.SubscriberEmailAddress != null)
                        emailAddr = encPlan.SubscriberEmailAddress.Street_Addr;
                    else
                        emailAddr = string.Empty;
                    mtBAR.UpdateInsuranceSubscriber(cnt, "", encPlan.SubscriberPerson.FullName(), encPlan.SubscriberPerson.SocialSecurityNumber, encPlan.SubscriberPerson.Sex_Cd, ConvertDate(encPlan.SubscriberPerson.Birth_Dt_Tm), encPlan.Relationship.Replace(".0000",""), addr1,
                                   addr2, city, state, zipCode, country, businessPhone, emailAddr, encPlan.SubscriberPerson.Race_Cd, encPlan.SubscriberPerson.Marital_Type_Cd);
                }
                string item = "";
                if (encPlan.Authorizations != null)
                {
                    foreach (Authorization authorization in encPlan.Authorizations)
                    {
                        string authnbr = authorization.Authorization_Nbr;
                        string authsts = authorization.Authorization_Status;
                        //if (authnbr == null)
                        //    authnbr = "";
                        //if (authsts == null)
                        //    authsts = "";
                        //if (authnbr == "null" || authnbr == "0")
                        //    authnbr = "";
                        //if (authsts == "null" || authsts == "0")
                        //    authsts = "";
                        if (authnbr.Trim() == "" && authsts.Trim() == "")
                            item = "N";
                        else
                            mtBAR.AddInsuranceAuthorizations(cnt, authnbr, ConvertDate(authorization.Authorization_EffDate), ConvertDate(authorization.Authorization_ExpDate), authsts, authorization.Authorization_ReferalNbr);
                    }
                }
            }


            //mtBAR.AddInsurance(1, "Ins1", "name1,Last", "Address1", "Address2", "City1", "SC", "29601", "111-111-1111", DateTime.Today, 1.1M, 1.2M, 1.3M, "Status1", DateTime.Today, DateTime.Today,
            //    "policy1", "GroupNbr1", "GroupName1");
            //mtBAR.AddInsurance(2, "Ins2", "name2,Last", "Address2", "Address22", "City2", "SC", "29602", "222-111-1111", DateTime.Today, 2.1M, 2.2M, 2.3M, "Status2", DateTime.Today, DateTime.Today,
            //    "policy2", "GroupNbr2", "GroupName2");
            //mtBAR.AddInsurance(3, "Ins3", "name3,Last", "Address3", "Address23", "City3", "SC", "29603", "333-111-1111", DateTime.Today, 3.1M, 3.2M, 3.3M, "Status3", DateTime.Today, DateTime.Today,
            //    "policy3", "GroupNbr3", "GroupName3");

            //mtBAR.UpdateInsuranceSubscriber(2, "unr2", "LastName,2", "222-11-1111", "M", DateTime.Today, "R2", "Address2", "Address2", "City2", "SC", "29602", "Country2", "222-111-1111", "Email2.com", "R2", "M2");
            //mtBAR.UpdateInsuranceSubscriber(3, "unr3", "LastName,3", "333-11-1111", "M", DateTime.Today, "R3", "Address3", "Address3", "City3", "SC", "29603", "Country3", "333-111-1111", "Email3.com", "R3", "M3");

            
            //mtBAR.AddInsuranceAuthorizations(2, "Auth2.1", DateTime.Today, DateTime.Today, "Status2.1", "Referal2.1");
            //mtBAR.AddInsuranceAuthorizations(2, "Auth3", DateTime.Today, DateTime.Today, "Status3", "Referal3");
            //mtBAR.AddInsuranceAuthorizations(2, "Auth4.1", DateTime.Today, DateTime.Today, "Status4.1", "Referal4.1");

            //mtBAR.AddInsuranceQuery(3, "Query1", "Response1");
            //mtBAR.AddInsuranceQuery(3, "Query2", "Response2");
            //mtBAR.AddInsuranceQuery(3, "Query3", "Response3");
            //mtBAR.AddInsuranceQuery(3, "Query4", "Response4");
            //mtBAR.AddInsuranceQuery(3, "Query5", "Response5");

        }

        private void PatientQueries()
        {
            mtBAR.AddPatientQuery("Query1", "Response1");
            mtBAR.AddPatientQuery("Query2", "Response2");
            mtBAR.AddPatientQuery("Query3", "Response3");
            mtBAR.AddPatientQuery("Query4", "Response4");
            mtBAR.AddPatientQuery("Query5", "Response5");
            mtBAR.AddPatientQuery("Query6", "Response5");

        }

        private void CurrentBalance(PFT_Encntr pft_Encnter, List<PftProration> proRateList)
        {
            string ins = "";
            mtBAR.BalanceRecord.PatientAccountNumber = mtBAR.CurrentAccountNumber;
            if (_barStatus == "FB" || _barStatus == "UB")
            {
                mtBAR.BalanceRecord.AccountBalance = GetBalance(pft_Encnter.Balance, pft_Encnter.Dr_Cr_Flag);
                _globalFBBalance = _globalFBBalance + mtBAR.BalanceRecord.AccountBalance;
            }
            foreach (PftProration pro in proRateList)
            {
                if (_globalInsHash.ContainsKey(1) == true)
                {
                    ins = _globalInsHash[1].ToString();
                    if (ins == pro.HealthPlanID.Trim())
                    {
                        mtBAR.BalanceRecord.InsuranceBalance1 = GetBalance(pro.CurrAmtDue, pro.CurrAmtDueFlg);
                        mtBAR.BalanceRecord.InsuranceReceipts1 = 999;
                    }
                }
                else if (_globalInsHash.ContainsKey(2) == true)
                {
                    ins = _globalInsHash[2].ToString();
                    if (ins == pro.HealthPlanID.Trim())
                    {
                        mtBAR.BalanceRecord.InsuranceBalance2 = GetBalance(pro.CurrAmtDue, pro.CurrAmtDueFlg);
                        mtBAR.BalanceRecord.InsuranceReceipts2 = 999;
                    }
                }
                else if (_globalInsHash.ContainsKey(3) == true)
                {
                    ins = _globalInsHash[3].ToString();
                    if (ins == pro.HealthPlanID.Trim())
                    {
                        mtBAR.BalanceRecord.InsuranceBalance3 = GetBalance(pro.CurrAmtDue, pro.CurrAmtDueFlg);
                        mtBAR.BalanceRecord.InsuranceReceipts3 = 999;
                    }
                }
                else if (_globalInsHash.ContainsKey(4) == true)
                {
                    ins = _globalInsHash[4].ToString();
                    if (ins == pro.HealthPlanID.Trim())
                    {
                        mtBAR.BalanceRecord.InsuranceBalance4 = GetBalance(pro.CurrAmtDue, pro.CurrAmtDueFlg);
                        mtBAR.BalanceRecord.InsuranceReceipts4 = 999;
                    }

                }

            }
            mtBAR.BalanceRecord.SelfPayBalance = pft_Encnter.Pat_Bal_Fwd;
            if (_barStatus == "FB" || _barStatus == "UB")
                mtBAR.BalanceRecord.URBalance = GetBalance(pft_Encnter.Balance, pft_Encnter.Dr_Cr_Flag);
            if (_barStatus == "BD")
            {
                mtBAR.BalanceRecord.BadDebtBalance = GetBalance(pft_Encnter.Bad_Debt_Balance, pft_Encnter.Bad_Debt_Bal_Dr_Cr_Flag);
                _globalBDBalance = _globalBDBalance + mtBAR.BalanceRecord.BadDebtBalance;
            }
        }

        private void ProcessChargesTransactions(PFT_Encntr pft_Encnter, string facility)
        {
            string amt = "";
            string reversingFlag = string.Empty;
            decimal? amount = 0;
            List <Charge> charges = ChargeDAL.GetCharges(pft_Encnter.Encntr_Id, facility);
            foreach(Charge charge in charges)
            {
                amt = "";
                reversingFlag = "";
                amount = 0;

                string transactionType = "CHG";
                DateTime? serviceDate = CernerCommon.ConvertDateString(charge.Service_Dt_Tm);
                string chargeCode = charge.Charge_Item_Id;
                int? count = int.Parse(Math.Round(Double.Parse(charge.Quantity),MidpointRounding.AwayFromZero).ToString());
                amt = charge.Item_Extended_Price;
                if (amt.Contains("-") == true)
                {
                    amt = amt.Replace("-", "");
                    amount = CernerCommon.ConvertDecimalString(amt);
                    reversingFlag = "1";
                }
                else
                {
                    amount = CernerCommon.ConvertDecimalString(amt);
                    reversingFlag = "";
                }
                string billNumber = string.Empty;
                string comment = string.Empty;
                string insurance = charge.Payor_Id;
                string perfPhys = charge.Perf_Phy_Id;

                string orderPhys = charge.Ord_Phy_Id;
                string revenueSite = string.Empty;
                string nonChargeCode = string.Empty;
                string user = charge.User_Id;
                string systemComment = string.Empty;

                mtBAR.AddTransactionRecord(transactionType, serviceDate, chargeCode, count, amount, billNumber,
                    reversingFlag, comment, insurance, perfPhys, orderPhys, revenueSite, nonChargeCode, user, systemComment);
            }

            List<Pft_Trans_Reltn_Trans_Log> pftTransReltns = Pft_Trans_Reltn_Trans_LogDAL.GetPft_Trans_Reltn_Trans_Records(pft_Encnter.Pft_Encntr_Id);
            foreach (Pft_Trans_Reltn_Trans_Log pftTranReltn in pftTransReltns)
            {
                string transactionType = pftTranReltn.Trans_Type_Cd;
                if (transactionType == "10978")
                    transactionType = "ADJ";
                else if (transactionType == "10982")
                    transactionType = "PAY";
                DateTime? serviceDate = CernerCommon.ConvertDateString(pftTranReltn.Beg_Eff_Dt_Tm);
                string chargeCode = Pft_Trans_AliasDAL.GetTransAlias(pftTranReltn.Trans_Alias_ID.Trim());
                int? count = 0;

                amt = pftTranReltn.Amount;
                if (amt.Contains("-") == true)
                {
                    amt = amt.Replace("-", "");
                    amount = CernerCommon.ConvertDecimalString(amt);
                    reversingFlag = "1";
                }
                else
                {
                    amount = CernerCommon.ConvertDecimalString(amt);
                    reversingFlag = "";
                }

                string billNumber = string.Empty;
                string comment = string.Empty;
                string insurance = string.Empty;
                string perfPhys = string.Empty;
                string orderPhys = string.Empty;
                string revenueSite = string.Empty;
                string nonChargeCode = string.Empty;
                string user = string.Empty;
                string systemComment = string.Empty;

                mtBAR.AddTransactionRecord(transactionType, serviceDate, chargeCode, count, amount, billNumber,
                    reversingFlag, comment, insurance, perfPhys, orderPhys, revenueSite, nonChargeCode, user, systemComment);
            }
        }


        private List<string> GetOrganizations(string hcis, string hospFac)
        {
            List<string> orgs = new List<string>();
            orgs = MPIOrganizationDAL.GetOrganizationsToProcess(hcis, hospFac);
            return orgs;
        }

        private DateTime? ConvertDate(string dt)
        {
            DateTime? newDt;
            if (IsDate(dt) == true)
                newDt = DateTime.Parse(dt);
            else
                newDt = null;
            return newDt;
        }
        public static bool IsDate(string dt)
        {
            try
            {
                DateTime testDt = DateTime.Parse(dt);
                return true;
            }
            catch
            {
                return false;
            }
        }
        public static string FormatDT(string dt, string returnVal)
        {
            if (dt.Trim() == "")
                return "";
            else if (IsDate(dt) == true)
            {
                DateTime dateTime = DateTime.Parse(dt);
                if (returnVal == "date")
                {
                    string day = string.Format("{0:00}", dateTime.Day);
                    string month = string.Format("{0:00}", dateTime.Month);
                    string year = string.Format("{0:0000}", dateTime.Year);
                    return year + month + day;
                }
                else
                {
                    string time = dateTime.ToString("HH:mm");
                    return time;
                }
            }
            else
                return "";
        }
        public static string FormatDT(DateTime dateTime, string returnVal)
        {
            //if (dt.Trim() == "")
            //    return "";
            
            //DateTime dateTime = DateTime.Parse(dt);
            if (returnVal == "date")
            {
                string day = string.Format("{0:00}", dateTime.Day);
                string month = string.Format("{0:00}", dateTime.Month);
                string year = string.Format("{0:0000}", dateTime.Year);
                return year + month + day;
            }
            else
            {
                string time = dateTime.ToString("HH:mm");
                return time;
            }
            
        }
        private void SetGrouperVersion(DateTime? dischargeDate)
        {
            if (dischargeDate >= new DateTime(2015, 10, 01) && dischargeDate <= new DateTime(2016, 9, 30))
                _grouperVersion = "33";
            else if (dischargeDate >= new DateTime(2016, 10, 1) && dischargeDate <= new DateTime(2017, 9, 30))
                _grouperVersion = "34";
            else if (dischargeDate >= new DateTime(2017, 10, 1) && dischargeDate <= new DateTime(2018, 9, 30))
                _grouperVersion = "35";
        }

        private decimal? GetBalance(decimal? bal, string flg)
        {
            if (flg.Trim() == "2")
                bal = bal * -1;
            return bal;
        }
        private static string CheckSSN(string ssn)
        {
            ssn = ssn.Replace("-", "");
            if (ssn.Distinct().Count() > 1 && ssn != "999999999")
                ssn.PadLeft(9, '0');
            else
                ssn = "";
            return ssn;
        }
    }
}
